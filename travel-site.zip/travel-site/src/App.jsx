import { useState } from 'react'


import Navbar from './components/Navbar'
import 'bootstrap/dist/css/bootstrap.min.css'
import SearcPart from './components/SearcPart'
import MostViewed from './components/MostViewed'
import Footer from './components/Footer'

function App() {
 

  return (
    <>
      <Navbar/>
      <SearcPart/>
      <MostViewed/>
      <Footer/>
    </>
  )
}

export default App
