import {Data} from './Data'
import SingleCityCard from './SingleCityCard'

function MostViewed() {
  return (
    <>
    <div className='container'>
      <h3>Most Visited Cities of the World</h3>
    <div className="row row-cols-sm-2 row-cols-md-3">
    {
      Data.map(city=><SingleCityCard key={city.id} city={city}/> )
    }
    </div>
    </div>
    </>
  )
}

export default MostViewed
