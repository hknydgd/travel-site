export const Data = [

    {
        "id": "1",
        "title": "Bangkok - THAILAND",
        "description": "At the top of the list is Bangkok, the bustling capital of Thailand. Known for its vibrant street life, rich cultural heritage, and mouthwatering cuisine, Bangkok has rightfully earned its reputation as the most visited city in the world. With an estimated 22.78 million visitors in 2023, it’s no wonder that travelers from all corners of the globe flock to this enchanting city.",
        "flight_price": "$581",
        "thumbnail": "https://theworldcountries.com/wp-content/uploads/2023/08/Bangkok-1024x682.jpg"
    },
    {
        "id": "2",
        "title": "Paris - FRANCE",
        "description": "Paris, the romantic capital of France, holds the second spot on the list with an impressive 19.10 million visitors in 2023. Known for its timeless beauty, exquisite architecture, and world-class art collections, Paris has a certain allure that captivates the hearts of travelers.",
        "flight_price": "$601",
        "thumbnail": "https://theworldcountries.com/wp-content/uploads/2023/08/kota-paris-eiffel.webp"
    },
    {
        "id": "3",
        "title": "London - ENGLAND",
        "description": "London, the capital of the United Kingdom, secures the third position with 19.09 million visitors in 2023. Known for its rich history, cultural diversity, and iconic landmarks, London has something to offer for every type of traveler.",
        "flight_price": "$831",
        "thumbnail": "https://theworldcountries.com/wp-content/uploads/2023/08/London.jpg"
    },
    {
        "id": "4",
        "title": "Dubai - UNITED ARAB EMIRATES",
        "description": "Dubai, the futuristic city in the United Arab Emirates, ranks fourth on the list with 15.93 million visitors in 2023. Known for its awe-inspiring architecture, luxurious shopping malls, and pristine beaches, Dubai offers a unique blend of opulence and adventure.",
        "flight_price": "$916",
        "thumbnail": "https://theworldcountries.com/wp-content/uploads/2023/08/Dubai-United-Arab-Emirates-Burj-Khalifa-top-1024x577.webp"
    },
    {
        "id": "5",
        "title": "Singapore - SINGAPORE",
        "description": "Singapore, the vibrant city-state in Southeast Asia, takes the fifth spot with 14.67 million visitors in 2023. Known for its impeccable cleanliness, efficient transportation system, and diverse multicultural heritage, Singapore offers a truly unique travel experience.",
        "flight_price": "$581",
        "thumbnail": "https://theworldcountries.com/wp-content/uploads/2023/08/Singapore.jpg"
    },
    {
        "id": "6",
        "title": "Kuala Lumpur - MALAYSIA",
        "description": "Kuala Lumpur, the capital of Malaysia, secures the sixth position with 13.79 million visitors in 2023. Known for its towering skyscrapers, vibrant street markets, and diverse culinary scene, Kuala Lumpur is a melting pot of cultures and a gateway to Southeast Asia.",
        "flight_price": "$472",
        "thumbnail": "https://theworldcountries.com/wp-content/uploads/2023/08/Kuala-Lumpur.jpg"
    },
    {
        "id": "7",
        "title": "New York - USA",
        "description": "New York City, the epitome of the American dream, ranks seventh on the list with 13.60 million visitors in 2023. Known for its iconic skyline, world-class museums, and vibrant atmosphere, New York City offers an unparalleled urban experience.",
        "flight_price": "$649",
        "thumbnail": "https://theworldcountries.com/wp-content/uploads/2023/08/New-York-1024x682.jpg"
    },
    {
        "id": "8",
        "title": "İstanbul - TÜRKİYE",
        "description": "Istanbul, the transcontinental city straddling Europe and Asia, secures the eighth position with 13.40 million visitors in 2023. Known for its rich history, stunning architecture, and vibrant markets, Istanbul offers a unique blend of Eastern and Western influences.",
        "flight_price": "$480",
        "thumbnail": "https://theworldcountries.com/wp-content/uploads/2023/08/Istanbul.jpg"
    },
    {
        "id": "9",
        "title": "Tokyo - JAPAN",
        "description": "Tokyo, the capital of Japan, takes the ninth spot with 12.93 million visitors in 2023. Known for its cutting-edge technology, traditional temples, and unique pop culture, Tokyo offers a one-of-a-kind experience for travelers.",
        "flight_price": "$743",
        "thumbnail": "https://theworldcountries.com/wp-content/uploads/2023/08/Tokyo.jpg"
    },
    
]