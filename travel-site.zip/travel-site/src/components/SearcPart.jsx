import React from 'react'
import istanbul from '../assets/istanbul.webm'
import '../special.css'
function SearcPart() {
  return (
    <div className='container'>
      <div style={{ position: "relative" }}>
        <video src={istanbul} muted autoPlay loop type='video/webm' className='video'></video>
        <div className='special'>
          <input type='text' placeholder='Search a city' className='inputlar' id="search"/>

          <input type="date" id="start" name="trip-start" value="2023-01-20" min="2023-01-01" max="2025-12-31" className='inputlar'/>
          <input type="range" id="vol" name="vol" min="0" max="1000" className='inputlar'/>$1000
        </div>
      </div>
      </div>
      )
}

      export default SearcPart
