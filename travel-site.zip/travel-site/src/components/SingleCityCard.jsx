

function SingleCityCard({city}) {

  return (
    <>
    <div className="col-sm mb-3">
      <div className="card" >
        <img src={city.thumbnail} className="card-img-top" alt={city.title} />
        <div className="card-body">
          <h5 className="card-title">{city.title}</h5>
          <p> flight_price: {city.flight_price}</p>
          <p className="card-text">{city.description}</p>
          <a href="#" className="btn btn-primary">Book now</a>
        </div>
      </div>
      </div>
    </>
  )
}

export default SingleCityCard
